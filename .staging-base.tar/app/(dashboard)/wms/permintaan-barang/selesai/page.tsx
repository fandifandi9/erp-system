export { default } from "./WmsSelesaiContent";
