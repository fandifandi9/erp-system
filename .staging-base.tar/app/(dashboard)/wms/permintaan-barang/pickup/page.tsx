export { default } from "./WmsPickupContent";
