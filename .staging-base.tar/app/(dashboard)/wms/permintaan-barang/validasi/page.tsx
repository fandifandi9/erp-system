export { default } from "./WmsValidasiContent";
