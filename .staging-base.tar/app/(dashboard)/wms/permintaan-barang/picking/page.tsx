export { default } from "./WmsPickingContent";
